@include("laraflat::fileds.php.text" , [  "label"  => trans("users::users.name")  , "value" => $row->name ?? null  ,  "name" =>"name" ])
@include("laraflat::fileds.php.email" , [  "label"  => trans("users::users.email")  , "value" => $row->email ?? null  ,  "name" =>"email" ])
@include("laraflat::fileds.php.password" , [  "label"  => trans("users::users.password")  ,  "name" =>"password" ])
@include("laraflat::fileds.php.image" , [  "label"  => trans("users::users.avatar")  , "value" => $row->avatar ?? null  ,  "name" =>"avatar" ])

@include("laraflat::fileds.php.radio" , [  "label"  => trans("laraflat::laraflat.Active") , "array" => [0 => trans("laraflat::laraflat.No") , 1 => trans("laraflat::laraflat.Yes") ]  , "selectedArray" => (array) $row->active ?? null  ,  "name" =>"active" ])