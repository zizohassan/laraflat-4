{!! Form::open(['route' => 'users.index' , 'method' => 'GET']) !!}
<div class="row">
	<div class="col-lg-2">
		@include("laraflat::fileds.php.text" , [  "label"  => trans("users::users.name")  , "value" => request()->has("name")  && request()->get("name")  != "" ?  request()->get("name") : null  ,  "name" =>"name" ])
	</div>
	<div class="col-lg-2">
		@include("laraflat::fileds.php.email" , [  "label"  => trans("users::users.email")  , "value" => request()->has("email")  && request()->get("email")  != "" ?  request()->get("email") : null  ,  "name" =>"email" ])
	</div>

<div class="col-lg-2" style="margin-top: 30px;">
    @include("laraflat::fileds.php.radio" , [  "label"  => trans("laraflat::laraflat.Active") , "array" => [0 => trans("laraflat::laraflat.No") , 1 => trans("laraflat::laraflat.Yes") ] , "name" =>"active" ])
</div>
	{!! Form::submit(trans('users::users.Search') , ['class' => 'btn btn-info' , 'style' => "margin-top:25px"]) !!}
	<a href="{{ route('users.index') }}" class="btn btn-warning"  style="margin-top:25px">{{ trans('users::users.Reset') }}</a>
</div>
{!! Form::close() !!}
