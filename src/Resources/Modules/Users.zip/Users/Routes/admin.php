<?php

Route::group(['prefix' => LaravelLocalization::setLocale(), 'middleware' => ['localeSessionRedirect', 'localizationRedirect' ]], function () {

    Route::group([
        'prefix' => '/admin',
        'namespace' => 'App\Modules\Users\Http\Controllers\Admin',
        'middleware' => ['web']
    ], function () {


    Route::resource('users', 'UsersController');
    Route::get('users/active/{id}', 'UsersController@active')->name('users.active');
    Route::get('users/delete/{id}/{field}', 'UsersController@deleteFile')->name('users.delete');

    });

});
