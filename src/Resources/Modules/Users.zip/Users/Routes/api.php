<?php
Route::group([
  'prefix' => 'api/v1',
  'namespace' => 'App\Modules\Users\Http\Controllers\Api',
  'middleware' => [
    'api',
    'Laraflat\Laraflat\Laraflat\Middelware\ParseMultipartFormDataInputForNonPostRequests'
  ]
], function () {

  Route::resource('users', 'UsersController' , [ 'as' => 'api' ]);

});

