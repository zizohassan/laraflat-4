<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (!Schema::hasColumns('users' , ['group_id' , 'active' , 'avatar'])) {
            Schema::table('users', function (Blueprint $table) {
                $table->boolean('active')->default(1);
                $table->integer('group_id')->default(0);
				$table->string("avatar")->nullable();
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
