<?php
namespace App\Modules\Users\Database\Seeds;

use App\Modules\Users\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Laraflat\Laraflat\Laraflat\Models\MenuItem;

class UsersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        /*
         * module row insert in case you fresh your database
         * you will find your module info still save
         */

        $array = [
            'id' => '1',
            'name' => 'Users',
            'admin' => 'yes',
            'website' => 'no',
            'api' => 'yes',
        ];


        \Laraflat\Laraflat\Laraflat\Models\Module::create($array);

        /*
         * column row insert in case you fresh your database
         * you will find your column info still save
         */

        $array = [
            [
                'id' => '4',
                'name' => 'name',
                'modifiers' => '',
                'column' => 'string',
                'module_id' => '1',
                'multi_lang' => '0',
            ],
            [
                'id' => '5',
                'name' => 'email',
                'modifiers' => 'unique',
                'column' => 'string',
                'module_id' => '1',
                'multi_lang' => '0',
            ],
            [
                'id' => '6',
                'name' => 'password',
                'modifiers' => '',
                'column' => 'string',
                'module_id' => '1',
                'multi_lang' => '0',
            ],
            [
                'id' => '7',
                'name' => 'avatar',
                'modifiers' => '',
                'column' => 'string',
                'module_id' => '1',
                'multi_lang' => '0',
            ],
        ];


        \Laraflat\Laraflat\Laraflat\Models\Column::insert($array);

        /*
       * column Details row insert in case you fresh your database
       * you will find your column Details info still save
       */

        $array = [
            [
                'id' => '8',
                'validation' => '{"required":"required","min":"2","max":"191"}',
                'transformer' => 'yes',
                'admin_crud' => 'yes',
                'site_crud' => 'no',
                'html_type' => 'text',
                'column_id' => '4',
                'module_id' => '1',
                'admin_filter' => 'yes',
                'website_filter' => 'no',
                'custom_validation' => '',
            ],
            [
                'id' => '9',
                'validation' => '{"required":"required","email":"email","unique":"unique","min":"6","max":"191"}',
                'transformer' => 'yes',
                'admin_crud' => 'yes',
                'site_crud' => 'no',
                'html_type' => 'email',
                'column_id' => '5',
                'module_id' => '1',
                'admin_filter' => 'yes',
                'website_filter' => 'no',
                'custom_validation' => '',
            ],
            [
                'id' => '10',
                'validation' => '{"required":"required","nullable":"nullable","min":"6","max":"191"}',
                'transformer' => 'no',
                'admin_crud' => 'no',
                'site_crud' => 'no',
                'html_type' => 'password',
                'column_id' => '6',
                'module_id' => '1',
                'admin_filter' => 'no',
                'website_filter' => 'no',
                'custom_validation' => '',
            ],
            [
                'id' => '11',
                'validation' => '{"required":"required"}',
                'transformer' => 'yes',
                'admin_crud' => 'yes',
                'site_crud' => 'no',
                'html_type' => 'image',
                'column_id' => '7',
                'module_id' => '1',
                'admin_filter' => 'no',
                'website_filter' => 'no',
                'custom_validation' => 'image',
            ],
        ];


        \Laraflat\Laraflat\Laraflat\Models\ColumnDetail::insert($array);

        /*
        * Module Relation row insert in case you fresh your database
        * you will find your column Details info still save
        */

        $array = [
        ];


        if(!empty($array)){
            \Laraflat\Laraflat\Laraflat\Models\Relation::insert($array);
        }


        /*
          * Add Admin user
          */

        User::create([
            'name' => 'laraflat',
            'email' => 'admin@laraflat.com',
            'password' => Hash::make('laraflat'),
            'group_id' => 1
        ]);


        /*
         * generate user menu item
         */

        $parent = [
            'name_ar' => 'الاعضاء',
            'name_en' => 'Users',
            'slug' => 'Users',
            'order' => 2,
            'menu_id' => 1,
            'parent_id' => 0,
            'icon' => '<i class="fa fa-users"></i>',
            'link' => ''
        ];

        $parent = MenuItem::create($parent);

        $items = [
            [
                'name_ar' => 'الاعضاء',
                'name_en' => 'Control Users',
                'slug' => 'Users',
                'order' => 0,
                'menu_id' => 1,
                'parent_id' => $parent->id,
                'icon' => '',
                'link' => '/admin/users'
            ],
            [
                'name_ar' => 'اضافة عضو',
                'name_en' => 'Create Users',
                'slug' => 'Users',
                'order' => 0,
                'menu_id' => 1,
                'parent_id' => $parent->id,
                'icon' => '',
                'link' => '/admin/users/create'
            ],
        ];

        MenuItem::insert($items);

    }
}
